
// ============================================
// VIRTUAL LAB NETWORK TRAFFIC LIGHT
// FRONTEND DASHBOARD CONTROLLER
// ============================================

const API_URL = "/api";

let monitoringTimer = null;
let networkHistory = [];
let activityLogs = [];
let isChecking = false;


// ============================================
// DOM ELEMENT HELPER
// ============================================

function getElement(id) {
    return document.getElementById(id);
}


// ============================================
// CURRENT DATE
// ============================================

function updateDate() {

    const date = new Date();

    getElement("currentDate").textContent =
        date.toLocaleDateString("en-IN", {
            day: "2-digit",
            month: "short",
            year: "numeric"
        });
}


// ============================================
// TRAFFIC LIGHT UPDATE
// ============================================

function updateTrafficLight(status) {

    const lights = [
        "redLight",
        "yellowLight",
        "greenLight"
    ];

    lights.forEach(id => {
        getElement(id).classList.remove("active");
    });

    const lightMap = {
        GREEN: "greenLight",
        YELLOW: "yellowLight",
        RED: "redLight"
    };

    const selectedLight = lightMap[status];

    if (selectedLight) {
        getElement(selectedLight).classList.add("active");
    }

}


// ============================================
// OVERALL STATUS
// ============================================

function updateOverall(data) {

    const status = data.overall_status;

    updateTrafficLight(status);

    getElement("mainStatus").textContent = status;

    const messages = {
        GREEN: "All AWS servers are reachable. Network is healthy.",
        YELLOW: "Partial network connectivity detected.",
        RED: "No AWS servers are responding. Check connectivity."
    };

    getElement("mainMessage").textContent =
        messages[status] || "Checking network...";

    getElement("connectedServers").textContent =
        data.connected_servers;

    getElement("disconnectedServers").textContent =
        data.disconnected_servers;

    getElement("totalServers").textContent =
        data.total_servers;

    getElement("averageLatency").textContent =
        data.average_latency === null
            ? "--"
            : data.average_latency + " ms";

    getElement("chartAverage").textContent =
        data.average_latency === null
            ? "-- ms"
            : data.average_latency + " ms";

    getElement("lastChecked").textContent =
        data.last_checked;

}


// ============================================
// INDIVIDUAL SERVER UPDATE
// ============================================

function updateServer(id, server) {

    const connected = server.status === "CONNECTED";

    const statusClass = connected
        ? "connected"
        : "disconnected";

    const statusText = connected
        ? "CONNECTED"
        : "DISCONNECTED";

    getElement(id + "IP").textContent = server.ip;

    getElement(id + "Status").textContent =
        statusText;

    getElement(id + "Latency").textContent =
        server.latency === null
            ? "--"
            : server.latency + " ms";

    getElement(id + "Message").textContent =
        server.message;

    getElement(id + "Dot").className =
        "server-dot " + statusClass;

    getElement(id + "Badge").textContent =
        statusText;

    getElement(id + "Badge").className =
        "badge " + statusClass;

}


// ============================================
// NETWORK HISTORY
// ============================================

function saveHistory(data) {

    const record = {
        time: data.last_checked,
        status: data.overall_status,
        latency: data.average_latency,
        connected: data.connected_servers
    };

    networkHistory.push(record);

    if (networkHistory.length > 60) {
        networkHistory.shift();
    }

    drawChart();
}


// ============================================
// CANVAS LATENCY GRAPH
// ============================================

function drawChart() {

    const canvas = getElement("latencyChart");

    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();

    if (!rect.width || !rect.height) return;

    const ctx = canvas.getContext("2d");

    const ratio = window.devicePixelRatio || 1;

    canvas.width = rect.width * ratio;
    canvas.height = rect.height * ratio;

    ctx.setTransform(ratio, 0, 0, ratio, 0, 0);

    const width = rect.width;
    const height = rect.height;

    ctx.clearRect(0, 0, width, height);

    const validData = networkHistory.filter(
        item => item.latency !== null
    );

    const styles = getComputedStyle(document.body);

    const muted = styles.getPropertyValue("--muted").trim();

    const border = styles.getPropertyValue("--border").trim();

    if (validData.length === 0) {

        ctx.fillStyle = muted;

        ctx.font = "13px Arial";

        ctx.textAlign = "center";

        ctx.fillText(
            "Waiting for network measurements...",
            width / 2,
            height / 2
        );

        return;
    }

    const left = 45;
    const right = width - 15;
    const top = 20;
    const bottom = height - 30;

    const maxLatency = Math.max(
        10,
        ...validData.map(item => item.latency)
    ) * 1.2;

    // Horizontal grid lines

    ctx.strokeStyle = border;
    ctx.lineWidth = 1;

    for (let i = 0; i <= 4; i++) {

        const y = top + (bottom - top) * i / 4;

        ctx.beginPath();
        ctx.moveTo(left, y);
        ctx.lineTo(right, y);
        ctx.stroke();

        ctx.fillStyle = muted;
        ctx.font = "10px Arial";
        ctx.textAlign = "right";

        const value = maxLatency * (4 - i) / 4;

        ctx.fillText(
            value.toFixed(0) + " ms",
            left - 7,
            y + 4
        );
    }

    // Graph line

    const points = validData.map((item, index) => {

        const x = validData.length === 1
            ? (left + right) / 2
            : left + index * (right - left) /
              (validData.length - 1);

        const y = bottom -
            (item.latency / maxLatency) *
            (bottom - top);

        return { x, y };
    });

    // Graph area

    ctx.beginPath();

    ctx.moveTo(points[0].x, bottom);

    points.forEach(point => {
        ctx.lineTo(point.x, point.y);
    });

    ctx.lineTo(points[points.length - 1].x, bottom);

    ctx.closePath();

    ctx.fillStyle = "rgba(37, 99, 235, 0.10)";

    ctx.fill();

    // Graph line

    ctx.beginPath();

    points.forEach((point, index) => {

        if (index === 0) {
            ctx.moveTo(point.x, point.y);
        } else {
            ctx.lineTo(point.x, point.y);
        }

    });

    ctx.strokeStyle = "#2563eb";
    ctx.lineWidth = 3;
    ctx.lineJoin = "round";
    ctx.lineCap = "round";

    ctx.stroke();

    // Data points

    points.forEach(point => {

        ctx.beginPath();

        ctx.arc(point.x, point.y, 4, 0, Math.PI * 2);

        ctx.fillStyle = "#2563eb";

        ctx.fill();

        ctx.strokeStyle = "#ffffff";
        ctx.lineWidth = 2;

        ctx.stroke();

    });

    ctx.textAlign = "center";
    ctx.fillStyle = muted;
    ctx.font = "10px Arial";

    ctx.fillText(
        "Recent network checks",
        (left + right) / 2,
        height - 5
    );

}


// ============================================
// ACTIVITY LOGS
// ============================================

function saveActivity(data) {

    const previous = activityLogs[0];

    const changed = !previous ||
        previous.status !== data.overall_status ||
        previous.connected !== data.connected_servers;

    // Keep every check in history, but only log
    // status changes to avoid duplicate event logs.

    if (changed) {

        activityLogs.unshift({
            time: data.last_checked,
            status: data.overall_status,
            connected: data.connected_servers,
            latency: data.average_latency
        });

    }

    if (activityLogs.length > 100) {
        activityLogs.pop();
    }

    renderLogs();

}


// ============================================
// RENDER ACTIVITY TABLE
// ============================================

function renderLogs() {

    const table = getElement("logTable");

    const search = getElement("searchLogs")
        .value.toLowerCase();

    const filter = getElement("filterLogs").value;

    const filtered = activityLogs.filter(log => {

        const matchesSearch =
            log.time.toLowerCase().includes(search) ||
            log.status.toLowerCase().includes(search);

        const matchesFilter =
            filter === "ALL" ||
            log.status === filter;

        return matchesSearch && matchesFilter;

    });

    if (filtered.length === 0) {

        table.innerHTML =
            '<tr><td colspan="4">No matching activity records.</td></tr>';

        return;
    }

    table.innerHTML = filtered.map(log => {

        const latency = log.latency === null
            ? "--"
            : log.latency + " ms";

        return `
            <tr>
                <td>${escapeHTML(log.time)}</td>

                <td>
                    <span class="log-status ${log.status}">
                        ${log.status}
                    </span>
                </td>

                <td>${log.connected} / 2</td>

                <td>${latency}</td>
            </tr>
        `;

    }).join("");

}


// ============================================
// HTML ESCAPE
// ============================================

function escapeHTML(value) {

    return String(value).replace(/[&<>"']/g, char => {

        const map = {
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#39;"
        };

        return map[char];

    });

}


// ============================================
// MAIN API CONNECTION
// ============================================

async function refreshDashboard() {

    if (isChecking) return;

    isChecking = true;

    const button = getElement("refreshButton");

    button.disabled = true;

    button.innerHTML =
        '<i class="fa-solid fa-spinner fa-spin"></i> Checking...';

    try {

        const response = await fetch(
            `${API_URL}/status`,
            { cache: "no-store" }
        );

        if (!response.ok) {
            throw new Error("API request failed: " + response.status);
        }

        const data = await response.json();

        updateOverall(data);

        updateServer("server1", data.servers.server1);

        updateServer("server2", data.servers.server2);

        saveHistory(data);

        saveActivity(data);

        console.log("AWS network data:", data);

    } catch (error) {

        console.error("Dashboard error:", error);

        getElement("mainStatus").textContent = "API ERROR";

        getElement("mainMessage").textContent =
            "Unable to contact Flask backend.";

        updateTrafficLight("RED");

    } finally {

        isChecking = false;

        button.disabled = false;

        button.innerHTML =
            '<i class="fa-solid fa-rotate"></i> Refresh';

    }

}


// ============================================
// AUTOMATIC MONITORING
// ============================================

function startMonitoring() {

    stopMonitoring();

    if (!getElement("autoRefresh").checked) {
        return;
    }

    const interval = Number(
        getElement("refreshInterval").value
    );

    monitoringTimer = setInterval(
        refreshDashboard,
        interval
    );

}

function stopMonitoring() {

    if (monitoringTimer !== null) {

        clearInterval(monitoringTimer);

        monitoringTimer = null;

    }

}


// ============================================
// CSV EXPORT
// ============================================

function exportLogs() {

    if (activityLogs.length === 0) {

        alert("No activity logs available.");

        return;
    }

    const rows = [
        ["Time", "Network Status", "Connected Servers", "Average Latency"]
    ];

    activityLogs.forEach(log => {

        rows.push([
            log.time,
            log.status,
            log.connected + "/2",
            log.latency === null ? "--" : log.latency + " ms"
        ]);

    });

    const csv = rows.map(row => {

        return row.map(value =>
            '"' + String(value).replace(/"/g, '""') + '"'
        ).join(",");

    }).join("\n");

    const blob = new Blob(
        ["\uFEFF" + csv],
        { type: "text/csv;charset=utf-8;" }
    );

    const url = URL.createObjectURL(blob);

    const link = document.createElement("a");

    link.href = url;

    link.download = "network_activity_logs.csv";

    link.click();

    URL.revokeObjectURL(url);

}


// ============================================
// DARK MODE
// ============================================

getElement("themeButton").addEventListener("click", () => {

    document.body.classList.toggle("dark");

    const dark = document.body.classList.contains("dark");

    getElement("themeButton").innerHTML = dark
        ? '<i class="fa-solid fa-sun"></i>'
        : '<i class="fa-solid fa-moon"></i>';

    drawChart();

});


// ============================================
// LOG SEARCH AND FILTER
// ============================================

getElement("searchLogs").addEventListener(
    "input",
    renderLogs
);

getElement("filterLogs").addEventListener(
    "change",
    renderLogs
);


// ============================================
// REFRESH SETTINGS
// ============================================

getElement("refreshInterval").addEventListener(
    "change",
    startMonitoring
);

getElement("autoRefresh").addEventListener(
    "change",
    startMonitoring
);


// ============================================
// SIDEBAR ACTIVE MENU
// ============================================

document.querySelectorAll(".menu-link").forEach(link => {

    link.addEventListener("click", () => {

        document.querySelectorAll(".menu-link")
            .forEach(item => item.classList.remove("active"));

        link.classList.add("active");

    });

});


// ============================================
// INITIALIZE DASHBOARD
// ============================================

document.addEventListener("DOMContentLoaded", () => {

    updateDate();

    refreshDashboard();

    startMonitoring();

});

window.addEventListener("resize", drawChart);
