
from datetime import datetime

from flask import Flask, abort, jsonify, render_template, send_from_directory
import boto3
from botocore.exceptions import ClientError, BotoCoreError

app = Flask(__name__, template_folder=".", static_folder=None)

# ---------------- AWS CONFIGURATION ----------------

AWS_REGION = "us-east-1"

SERVERS = {
    "Server A": "i-08b81c79018268d36",
    "Server B": "i-0e83f662c13092e48"
}

# Uses AWS CLI credentials configured on your laptop
ec2 = boto3.client(
    "ec2",
    region_name=AWS_REGION
)


# ---------------- DASHBOARD HOME ----------------

@app.route("/")
def home():
    return render_template("index.html")


@app.route("/static/<path:filename>", endpoint="static")
def static_file(filename):
    if filename not in {"style.css", "script.js"}:
        abort(404)
    return send_from_directory(app.root_path, filename)


# ---------------- SERVER STATUS API ----------------

def get_server_statuses():

    results = {}

    for name, instance_id in SERVERS.items():

        try:
            response = ec2.describe_instances(
                InstanceIds=[instance_id]
            )

            instances = [
                instance
                for reservation in response.get("Reservations", [])
                for instance in reservation.get("Instances", [])
            ]

            if instances:
                instance = instances[0]
                state = instance["State"]["Name"]
                private_ip = instance.get("PrivateIpAddress")
            else:
                state = "unknown"
                private_ip = None

            results[name] = {
                "instance_id": instance_id,
                "private_ip": private_ip,
                "state": state,
                "status": (
                    "Connected"
                    if state == "running"
                    else "Disconnected"
                )
            }

        except ClientError as error:

            error_code = error.response["Error"]["Code"]

            if error_code == "InvalidInstanceID.NotFound":
                state = "terminated"
            else:
                state = "error"

            results[name] = {
                "instance_id": instance_id,
                "private_ip": None,
                "state": state,
                "status": "Disconnected",
                "error": error_code
            }

        except BotoCoreError as error:

            results[name] = {
                "instance_id": instance_id,
                "private_ip": None,
                "state": "error",
                "status": "Disconnected",
                "error": str(error)
            }

    return results


@app.route("/api/server-status")
def server_status():
    return jsonify({
        "region": AWS_REGION,
        "servers": get_server_statuses()
    })


@app.route("/api/status")
def dashboard_status():
    server_results = get_server_statuses()
    configured_servers = list(SERVERS.items())
    connected_servers = sum(
        server_results[name]["status"] == "Connected"
        for name, _ in configured_servers
    )
    total_servers = len(configured_servers)

    if connected_servers == total_servers:
        overall_status = "GREEN"
    elif connected_servers:
        overall_status = "YELLOW"
    else:
        overall_status = "RED"

    servers = {}
    for index, (name, _) in enumerate(configured_servers, start=1):
        result = server_results[name]
        state = result["state"]
        servers["server" + str(index)] = {
            "status": (
                "CONNECTED"
                if result["status"] == "Connected"
                else "DISCONNECTED"
            ),
            "ip": result["private_ip"] or "Unavailable",
            "latency": None,
            "message": (
                "EC2 instance is " + state + "."
                if state != "error"
                else "Unable to retrieve EC2 instance status."
            )
        }

    return jsonify({
        "overall_status": overall_status,
        "connected_servers": connected_servers,
        "disconnected_servers": total_servers - connected_servers,
        "total_servers": total_servers,
        "average_latency": None,
        "last_checked": datetime.now().astimezone().strftime(
            "%d %b %Y, %I:%M:%S %p"
        ),
        "servers": servers
    })


# ---------------- HEALTH CHECK API ----------------

@app.route("/api/health")
def health():
    return jsonify({
        "application": "Virtual Lab Network Traffic Light",
        "status": "Running",
        "aws_region": AWS_REGION
    })


# ---------------- RUN FLASK ----------------

if __name__ == "__main__":
    app.run(
        host="127.0.0.1",
        port=5000,
        debug=True
    )
